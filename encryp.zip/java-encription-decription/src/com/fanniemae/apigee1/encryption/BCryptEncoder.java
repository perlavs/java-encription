package com.fanniemae.apigee1.encryption;


/**
 * this is the interface that is used to hash the data that is stored in the database.we are using spring implementation of BCRYPT with 16 as load factor.
 * remember this is one way hashing and there is no recoivering of the data once its hashed you can only compare it not decrypt it.
 */


public interface BCryptEncoder {

    /**
     * this method takes the data that is hashed and raw data that need to be compared.
     * it will take the rawdata and hash it and compares with the encrypted data and returns the result as boolean.
     * @param hashedData
     * @param rawData
     * @return boolean
     */
    public boolean compareHashData(final String hashedData, final String rawData);

    /**
     * this method is used to hash the data that is supplied. it used the strength that is given in the impl..
     * @param originalData
     * @return hashedData
     */
    public String hashData(final String originalData);

    public String decode(String encodedString);

    public String encode(byte[] bytes);
}
