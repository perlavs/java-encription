package com.fanniemae.apigee1.encryption;

import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;

import com.fanniemae.apigee1.encryption.EncryptionType;

/**
 * Created by sxuj4k on 3/30/2017.
 */
public interface EncryptionUtil
{
    public String getEncryptionToken(EncryptionType encryptionType) throws Exception;
    //public String encrypt(EncryptionType encryptionType, String data, String key);
    //public String decrypt(EncryptionType encryptionType, String data, String key) ;
    public String encrypt(String algorithm, String data, String key);
    public String decrypt(String algorithm, String data, String key) ;
    public KeyPair generateKey(EncryptionType encryptionType) throws NoSuchAlgorithmException, Exception;
    public String encrypt(EncryptionType encryptionType, String data, PublicKey publicKey) throws Exception, Exception;
    public String decrypt(EncryptionType encryptionType, String data, PrivateKey privateKey) throws Exception, Exception;
    public String hashData(String data);
    public boolean compareHashData(String hashedData, String data);
    public String encode(String data);
    public String decode(String data);
}
