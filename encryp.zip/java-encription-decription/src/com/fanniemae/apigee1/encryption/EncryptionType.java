package com.fanniemae.apigee1.encryption;

/**
 * Created by sxuj4k on 3/30/2017.
 */
public enum EncryptionType
{
    /**AES encryption using 128 key*/
    AES_1,
    /**AES encryption using 192 key, stronger than AES_1*/
    AES_2,
    /**AES encryption using 256 key, stronger than AES_2*/
    AES_3,

    /**RSA encryption using 1024 key*/
    RSA_1,
    /**RSA encryption using 2048 key, stronger than RSA_1*/
    RSA_2,
    /**RSA encryption using 4096 key, stronger than RSA_2*/
    RSA_3,

    /**AES encryption using 128 key*/
    AES_GCM_1,
    /**AES encryption using 192 key, stronger than AES_1*/
    AES_GCM_2,
    /**AES encryption using 256 key, stronger than AES_2*/
    AES_GCM_3,

    /**AES encryption using 128 key*/
    AES_CBC,
    /**AES encryption using 192 key, stronger than AES_1*/
    AES_GCM

    }
