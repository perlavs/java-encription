package com.fanniemae.apigee1.encryption;

import java.security.*;

/**
 *
 * <p>Title: RSAEncryptUtil</p>
 * <p>Description: Utility class that helps encrypt and decrypt strings using RSA algorithm</p>
 * @author Aviran Mordo http://aviran.mordos.com
 * @version 1.0
 */
public interface RSAEncryption
{
    static final String ALGORITHM = "RSA";

    public void init();

    public KeyPair generateKey(int type) throws NoSuchAlgorithmException;

    public byte[] encrypt(byte[] text, PublicKey key) throws Exception;

    public String encrypt(String text, PublicKey key) throws Exception;

    public byte[] decrypt(byte[] text, PrivateKey key) throws Exception;

    public String decrypt(String text, PrivateKey key) throws Exception;

    public String getKeyAsString(Key key);

    public PrivateKey getPrivateKeyFromString(String key) throws Exception;

    public PublicKey getPublicKeyFromString(String key) throws Exception;

    public void encryptFile(String srcFileName, String destFileName, PublicKey key) throws Exception;

    public void decryptFile(String srcFileName, String destFileName, PrivateKey key) throws Exception;

    public void encryptDecryptFile(String srcFileName, String destFileName, Key key, int cipherMode) throws Exception;

    public byte[] copyBytes(byte[] arr, int length);

}