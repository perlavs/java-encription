package com.fanniemae.apigee1.encryption.impl;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.StringUtils;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.fanniemae.apigee1.encryption.BCryptEncoder;

/**
 * this class is the implementation of the BCryptEncoder interface.
 */
public class BCryptEncoderImpl implements BCryptEncoder
{

    private BCryptPasswordEncoder bCryptPasswordEncoder;

    public boolean compareHashData(final String hashedData, final String rawData)
    {
        return bCryptPasswordEncoder.matches(rawData,hashedData);
    }

    public String hashData(final String originalData)
    {
        return bCryptPasswordEncoder.encode(originalData);
    }
    public String decode(String encodedString) {
        return StringUtils.newStringUtf8(Base64.decodeBase64(encodedString));
    }

    @Override
    public String encode(byte[] binaryData) {
        return Base64.encodeBase64String(binaryData);
    }
}
