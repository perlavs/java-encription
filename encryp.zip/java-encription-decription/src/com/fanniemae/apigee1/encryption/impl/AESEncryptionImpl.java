package com.fanniemae.apigee1.encryption.impl;

import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import com.fanniemae.apigee1.encryption.AESEncryption;
import com.fanniemae.apigee1.encryption.EncryptionConstants;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.AbstractMap;
import java.util.Collections;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Created by sxuvqt on 1/26/2017.
 */
public class AESEncryptionImpl implements AESEncryption
{

    private static final String AL_TYPE = "AES";
    private static final String AL_GCM_TYPE = "AES/GCM/NoPadding";
    private static final String CHARSET_NAME = "UTF-8";
    private static final int RADIX_LENGTH = 32;
    private static final int MULTIPLAYER = 5;
    private Cipher cipher;

    private static Map<Integer, Integer> aesEncryptionMap() {
        return Collections.unmodifiableMap(Stream.of(
                new AbstractMap.SimpleEntry<>(EncryptionConstants.AES_128,EncryptionConstants.AES_128_KEY_LENGTH),
                new AbstractMap.SimpleEntry<>(EncryptionConstants.AES_192,EncryptionConstants.AES_192_KEY_LENGTH),
                new AbstractMap.SimpleEntry<>(EncryptionConstants.AES_256,EncryptionConstants.AES_256_KEY_LENGTH))
                .collect(Collectors.toMap((e) -> e.getKey(), (e) -> e.getValue())));
    }

    public String encryptGCM(String plainText, String secretKey)
    {
        Cipher cipher = null;
        try
        {
            cipher = Cipher.getInstance(AL_GCM_TYPE);
        } catch(NoSuchAlgorithmException | NoSuchPaddingException e)
        {
//            cdxErrorUtils.throwBusinessException(EncryptionConstants.INVALID_ENCRYPTION_TYPE, Message.ERROR, HttpStatus.NOT_ACCEPTABLE, null, null);
        }
        byte[] plainTextByte = plainText.getBytes();
        try
        {
            cipher.init(Cipher.ENCRYPT_MODE, getSecKey(secretKey));
        } catch(InvalidKeyException | UnsupportedEncodingException e)
        {
//            cdxErrorUtils.throwBusinessException(EncryptionConstants.INVALID_ENCRYPTION_TYPE, Message.ERROR, HttpStatus.NOT_ACCEPTABLE, null, null);
        }
        byte[] iv = cipher.getIV();
        byte[] cipherText = new byte[0];
        try
        {
            cipherText = cipher.doFinal(plainTextByte);
        } catch(IllegalBlockSizeException | BadPaddingException e)
        {
//            cdxErrorUtils.throwBusinessException(EncryptionConstants.INVALID_ENCRYPTION_TYPE, Message.ERROR, HttpStatus.NOT_ACCEPTABLE, null, null);
        }
        byte[] message = new byte[12 + plainText.length() + 16];
        System.arraycopy(iv, 0, message, 0, 12);
        System.arraycopy(cipherText, 0, message, 12, cipherText.length);
        java.util.Base64.Encoder encoder = java.util.Base64.getEncoder();
        String encryptedText = encoder.encodeToString(message);
        return encryptedText;
    }

    public String decryptGCM(String data, String secretKey)
    {
        java.util.Base64.Decoder decoder = java.util.Base64.getDecoder();
        byte[] dataByte = decoder.decode(data);
        if (dataByte.length < 12 + 16)
        {
//            cdxErrorUtils.throwBusinessException(EncryptionConstants.INVALID_ENCRYPTION_TYPE, Message.ERROR, HttpStatus.NOT_ACCEPTABLE, null, null);
        }
        Cipher cipher = null;
        try
        {
            cipher = Cipher.getInstance(AL_GCM_TYPE);
        } catch(NoSuchAlgorithmException | NoSuchPaddingException e)
        {
//            cdxErrorUtils.throwBusinessException(EncryptionConstants.INVALID_ENCRYPTION_TYPE, Message.ERROR, HttpStatus.NOT_ACCEPTABLE, null, null);
        }
        GCMParameterSpec params = new GCMParameterSpec(128, dataByte, 0, 12);
        try
        {
            cipher.init(Cipher.DECRYPT_MODE, getSecKey(secretKey), params);
        } catch(InvalidKeyException | InvalidAlgorithmParameterException | UnsupportedEncodingException e)
        {
//            cdxErrorUtils.throwBusinessException(EncryptionConstants.INVALID_ENCRYPTION_TYPE, Message.ERROR, HttpStatus.NOT_ACCEPTABLE, null, null);
        }
        String decryptedText = null;
        try
        {
            decryptedText = new String(cipher.doFinal(dataByte, 12, dataByte.length - 12));
        } catch(IllegalBlockSizeException | BadPaddingException e)
        {
//            cdxErrorUtils.throwBusinessException(EncryptionConstants.INVALID_ENCRYPTION_TYPE, Message.ERROR, HttpStatus.NOT_ACCEPTABLE, null, null);
        }
        return decryptedText;
    }

    public String encrypt(String plainText, String secretKey){
        try {
			cipher = Cipher.getInstance(AL_TYPE);
		} catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
//			cdxErrorUtils.throwBusinessException(EncryptionConstants.INVALID_ENCRYPTION_TYPE, Message.ERROR, HttpStatus.NOT_ACCEPTABLE, null, null);
		}
        byte[] plainTextByte = plainText.getBytes();
        try {
			cipher.init(Cipher.ENCRYPT_MODE, getSecKey(secretKey));
		} catch (InvalidKeyException | UnsupportedEncodingException e) {
//			cdxErrorUtils.throwBusinessException(EncryptionConstants.INVALID_ENCRYPTION_TYPE, Message.ERROR, HttpStatus.NOT_ACCEPTABLE, null, null);
		}
        byte[] encryptedByte = null;
		try {
			encryptedByte = cipher.doFinal(plainTextByte);
		} catch (IllegalBlockSizeException | BadPaddingException e) {
//			cdxErrorUtils.throwBusinessException(EncryptionConstants.INVALID_ENCRYPTION_TYPE, Message.ERROR, HttpStatus.NOT_ACCEPTABLE, null, null);
		}
        java.util.Base64.Encoder encoder = java.util.Base64.getEncoder();
        String encryptedText = encoder.encodeToString(encryptedByte);
        return encryptedText;
    }

    public String decrypt(String data, String secretKey){
        try {
			cipher = Cipher.getInstance(AL_TYPE);
		} catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
//			cdxErrorUtils.throwBusinessException(EncryptionConstants.INVALID_ENCRYPTION_TYPE, Message.ERROR, HttpStatus.NOT_ACCEPTABLE, null, null);
		}
        java.util.Base64.Decoder decoder = java.util.Base64.getDecoder();
        byte[] dataByte = decoder.decode(data);
        try {
			cipher.init(Cipher.DECRYPT_MODE, getSecKey(secretKey));
		} catch (InvalidKeyException | UnsupportedEncodingException e) {
//			cdxErrorUtils.throwBusinessException(EncryptionConstants.INVALID_ENCRYPTION_TYPE, Message.ERROR, HttpStatus.NOT_ACCEPTABLE, null, null);
		}
        byte[] decryptedByte = null;
		try {
			decryptedByte = cipher.doFinal(dataByte);
		} catch (IllegalBlockSizeException | BadPaddingException e) {
//			cdxErrorUtils.throwBusinessException(EncryptionConstants.INVALID_ENCRYPTION_TYPE, Message.ERROR, HttpStatus.NOT_ACCEPTABLE, null, null);
		}
        String decryptedText = new String(decryptedByte);
        return decryptedText;
    }

    private String randomKey(int length) {
        Random random = new SecureRandom();
        return String.format("%" + length + "s", new BigInteger(length * MULTIPLAYER/*base 32,2^5*/, random)
                .toString(RADIX_LENGTH)).replace('\u0020', '0');
    }

    private SecretKey getSecKey(String randonStr) throws UnsupportedEncodingException {
        byte[] key = randonStr.getBytes(CHARSET_NAME);
        SecretKeySpec secretKeySpec = new SecretKeySpec(key, AL_TYPE);
        return secretKeySpec;
    }

    public String getEncryptionToken(int aesEncryptionType)
    {
    	System.out.println("key1");
        int keyLength = 0;
        if(aesEncryptionMap().containsKey(aesEncryptionType))
        {
            keyLength = aesEncryptionMap().get(aesEncryptionType);
        }
        if(keyLength > 0)
        {
        	
            return randomKey(keyLength);
        }
        else
        {
//        	cdxErrorUtils.throwBusinessException(EncryptionConstants.INVALID_ENCRYPTION_TYPE, Message.ERROR, HttpStatus.NOT_ACCEPTABLE, null, null);
        }
        return "";
    }

	/*
	 * public static void main(String a[]){ AESEncryptionImpl aesEncryption = new
	 * AESEncryptionImpl(); String token = aesEncryption.getEncryptionToken(1);
	 * System.out.println("generated token: " + token); String encrypted =
	 * aesEncryption.encryptGCM("Sample text to encrypt", token);
	 * System.out.println("encrypted value: " + encrypted); String decrypted =
	 * aesEncryption.decryptGCM(encrypted, token);
	 * System.out.println("decrypted value: " + decrypted); }
	 */
    
}
