package com.fanniemae.apigee1.encryption.impl;

import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;

import com.fanniemae.apigee1.encryption.AESEncryptionUtil;
import com.fanniemae.apigee1.encryption.EncryptionConstants;
import com.fanniemae.apigee1.encryption.EncryptionType;
import com.fanniemae.apigee1.encryption.EncryptionUtil;

/**
 * Created by sxuj4k on 3/30/2017.
 */
public class EncryptionUtilImpl implements EncryptionUtil
{
    AESEncryptionImpl aesEncryption;

    RSAEncryptionImpl rsaEncryption;

    BCryptEncoderImpl bCryptEncoder;

    public String encryptGCM(String data)
    {
        String ret = "";
        return ret;
    }

    /**Generates a token for encryption/decryption requiring a single key value*/
    public String getEncryptionToken(EncryptionType encryptionType) throws Exception
    {
        String ret="";
        switch(encryptionType)
        {
            case AES_1:ret = aesEncryption.getEncryptionToken(EncryptionConstants.AES_128);break;
            case AES_2:ret = aesEncryption.getEncryptionToken(EncryptionConstants.AES_192);break;
            case AES_3:ret = aesEncryption.getEncryptionToken(EncryptionConstants.AES_256);break;
            case AES_GCM_1:ret = aesEncryption.getEncryptionToken(EncryptionConstants.AES_128);break;
            case AES_GCM_2:ret = aesEncryption.getEncryptionToken(EncryptionConstants.AES_192);break;
            case AES_GCM_3:ret = AESEncryptionUtil.randomKey(EncryptionConstants.AES_256_KEY_LENGTH);break;
            default: //cdxErrorUtilsImpl.throwBusinessException(EncryptionConstants.INVALID_ENCRYPTION_TYPE, Message.ERROR, HttpStatus.NOT_ACCEPTABLE, null, null);
        }
        return ret;
    }

    /**Encrypts data using a key, the same one required to decrypt it*/
    public String encrypt(String algorithm, String data, String key)
    {
        String ret="";
        if("AES_CBC".equals(algorithm)) {
            try {
                ret = AESEncryptionUtil.encryptInput(data, key);
            } catch (Exception e) {
                //LOGGER.error("Caught error while decrypting for the data={}, key={}", data, key, e);
                e.printStackTrace();
                //cdxErrorUtilsImpl.throwBusinessException(EncryptionConstants.INVALID_ENCRYPTION_TYPE, Message.ERROR, HttpStatus.NOT_ACCEPTABLE, null, null);
            }
        }
        else if("AES_GCM".equals(algorithm)) {
            try {
            	System.out.println(data+key);
                //ret = aesEncryption.encryptGCM(data, key);
                ret = AESEncryptionUtil.encryptInput(data, key);
            } catch (Exception e) {
                //LOGGER.error("Caught error while decrypting for the data={}, key={}", data, key, e);
                e.printStackTrace();
                //cdxErrorUtilsImpl.throwBusinessException(EncryptionConstants.INVALID_ENCRYPTION_TYPE, Message.ERROR, HttpStatus.NOT_ACCEPTABLE, null, null);
            }
        }
        else
        {
            //cdxErrorUtilsImpl.throwBusinessException(EncryptionConstants.INVALID_ENCRYPTION_TYPE, Message.ERROR, HttpStatus.NOT_ACCEPTABLE, null, null);
        }
        return ret;
    }

    public String decrypt(String algorithm, String data, String key)
    {
        String ret="";
        if("AES_GCM".equals(algorithm))
        {
            try {
                //ret = aesEncryption.decryptGCM(data, key);
            	ret = AESEncryptionUtil.decryptInput(data, key);
            } catch (Exception e) {
                e.printStackTrace();
                //LOGGER.error("Caught error while decrypting for the data={}, key={}",data,key,e);
                //cdxErrorUtilsImpl.throwBusinessException(EncryptionConstants.INVALID_ENCRYPTION_TYPE, Message.ERROR, HttpStatus.NOT_ACCEPTABLE, null, null);
            }

        }else if("AES_CBC".equals(algorithm)){
            try {
                ret = AESEncryptionUtil.decryptInput(data, key);
            } catch (Exception e) {
                e.printStackTrace();
                //LOGGER.error("Caught error while decrypting for the data={}, key={}",data,key,e);
                //cdxErrorUtilsImpl.throwBusinessException(EncryptionConstants.INVALID_ENCRYPTION_TYPE, Message.ERROR, HttpStatus.NOT_ACCEPTABLE, null, null);
            }
        }
        else
        {
            //cdxErrorUtilsImpl.throwBusinessException(EncryptionConstants.INVALID_ENCRYPTION_TYPE, Message.ERROR, HttpStatus.NOT_ACCEPTABLE, null, null);
        }
        return ret;

    }

    /**Generates a token for encryption/decryption requiring a public and private key value*/
    public KeyPair generateKey(EncryptionType encryptionType) throws NoSuchAlgorithmException, Exception
    {
        KeyPair ret = null;
        switch(encryptionType)
        {
            case RSA_1:ret = rsaEncryption.generateKey(EncryptionConstants.RSA_1024_KEY);break;
            case RSA_2:ret = rsaEncryption.generateKey(EncryptionConstants.RSA_2048_KEY);break;
            case RSA_3:ret = rsaEncryption.generateKey(EncryptionConstants.RSA_4096_KEY);break;
            default://cdxErrorUtilsImpl.throwBusinessException(EncryptionConstants.INVALID_ENCRYPTION_TYPE, Message.ERROR, HttpStatus.NOT_ACCEPTABLE, null, null);
        }
        return ret;
    }

    /**Encrypts data using a public key. The matching private key will be required to decrypt it*/
    public String encrypt(EncryptionType encryptionType, String data, PublicKey publicKey) throws Exception, Exception
    {
        String ret="";
        switch(encryptionType)
        {
            case RSA_1:
            case RSA_2:
            case RSA_3:ret = rsaEncryption.encrypt(data, publicKey);break;
            default://cdxErrorUtilsImpl.throwBusinessException(EncryptionConstants.INVALID_ENCRYPTION_TYPE, Message.ERROR, HttpStatus.NOT_ACCEPTABLE, null, null);
        }
        return ret;
    }

    /**Decrypts data using a private key. Data must have been encrypted using the matching public key*/
    public String decrypt(EncryptionType encryptionType, String data, PrivateKey privateKey) throws Exception, Exception
    {
        String ret="";
        switch(encryptionType)
        {
            case RSA_1:
            case RSA_2:
            case RSA_3:ret = rsaEncryption.decrypt(data, privateKey);break;
            default://cdxErrorUtilsImpl.throwBusinessException(EncryptionConstants.INVALID_ENCRYPTION_TYPE, Message.ERROR, HttpStatus.NOT_ACCEPTABLE, null, null);
        }
        return ret;
    }

    public String hashData(String data)
    {
        return bCryptEncoder.hashData(data);
    }

    public boolean compareHashData(String hashedData, String data)
    {
        return bCryptEncoder.compareHashData(hashedData, data);
    }

    public String encode(String data)
    {
        java.util.Base64.Encoder encoder = java.util.Base64.getEncoder();
        String encryptedText = encoder.encodeToString(data.getBytes());
        return encryptedText;
    }

    public String decode(String data)
    {
        java.util.Base64.Decoder decoder = java.util.Base64.getDecoder();
        byte[] encryptedText = decoder.decode(data);
        return new String(encryptedText);
    }
    
}
