package com.fanniemae.apigee1.encryption;

/**
 * Created by sxuvqt on 2/28/17.
 */
public interface AESEncryption {
    public String getEncryptionToken(int encrptionType);
    public String decrypt(String data, String key);
    public String encrypt(String data, String key);
    public String decryptGCM(String data, String key);
    public String encryptGCM(String data, String key);
}
