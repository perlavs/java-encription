package com.fanniemae.apigee1.encryption;

/**
 * Created by sxuvqt on 2/28/17.
 */
public class EncryptionConstants {
    public static final int AES_128=1;
    public static final int AES_192=2;
    public static final int AES_256=3;

    public static final int AES_128_KEY_LENGTH=16;
    public static final int AES_192_KEY_LENGTH=24;
    public static final int AES_256_KEY_LENGTH=32;

    public static final int RSA_1024_KEY=1024;
    public static final int RSA_2048_KEY=2048;
    public static final int RSA_4096_KEY=4096;

    public static final String INVALID_ENCRYPTION_TYPE="ENC_001";

}
