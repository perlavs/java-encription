package com.fanniemae.apigee1.encryption;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Random;

/**
 * Created by sxunlt on 1/26/2017.
 */

public class AESEncryptionUtil
{
    private static final String AL_TYPE = "AES";
    private static final String CHARSET_NAME = "UTF-8";
    private static final int RADIX_LENGTH = 32;
    private static final int MULTIPLAYER = 5;
    private static Cipher cipher;

    /**
     * 1. Generate a plain text for encryption
     * 2. Get a secret key (printed in hexadecimal form). In actual use this must
     * by encrypted and kept safe. The same key is required for decryption.
     * 3.
     */
    public static void main(String[] args) throws Exception {
        String key = "bcv5riajgorpapho";
        System.out.println("userId: "+encryptInput("p3xbhsnj",key));
        System.out.println("password: "+encryptInput("MI8_CDDS",key));
       // String key = "bcv5riajgorpapho";
        System.out.println("userId: "+encryptInput("a09h0sxj",key));
        System.out.println("password: "+encryptInput("Jith_123",key));
    }

    public synchronized static String encryptInput(String plainText, String secretKey) throws Exception {
        cipher = Cipher.getInstance(AL_TYPE);
        byte[] plainTextByte = plainText.getBytes();
        cipher.init(Cipher.ENCRYPT_MODE, getSecKey(secretKey));
        byte[] encryptedByte = cipher.doFinal(plainTextByte);
        java.util.Base64.Encoder encoder = java.util.Base64.getEncoder();
        String encryptedText = encoder.encodeToString(encryptedByte);
        return encryptedText;
    }

    public synchronized static String decryptInput(String encryptedText, String secretKey)
            throws Exception {
        cipher = Cipher.getInstance(AL_TYPE);
        java.util.Base64.Decoder decoder = java.util.Base64.getDecoder();
        byte[] encryptedTextByte = decoder.decode(encryptedText);
        cipher.init(Cipher.DECRYPT_MODE, getSecKey(secretKey));
        byte[] decryptedByte = cipher.doFinal(encryptedTextByte);
        String decryptedText = new String(decryptedByte);
        return decryptedText;
    }

    public static String randomKey(int length) {
        Random random = new SecureRandom();
        return String.format("%" + length + "s", new BigInteger(length * MULTIPLAYER/*base 32,2^5*/, random)
                .toString(RADIX_LENGTH)).replace('\u0020', '0');
    }

    public static SecretKey getSecKey(String randonStr) throws UnsupportedEncodingException {
        byte[] key = randonStr.getBytes(CHARSET_NAME);
        SecretKeySpec secretKeySpec = new SecretKeySpec(key, AL_TYPE);
        return secretKeySpec;
    }
}
