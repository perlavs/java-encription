package com.fanniemae.apigee;

import com.apigee.flow.execution.ExecutionContext;
import com.apigee.flow.execution.ExecutionResult;
import com.apigee.flow.execution.spi.Execution;
import com.apigee.flow.message.Message;
import com.apigee.flow.message.MessageContext;
import com.fanniemae.apigee1.encryption.EncryptionType;
import com.fanniemae.apigee1.encryption.EncryptionUtil;
import com.fanniemae.apigee1.encryption.impl.EncryptionUtilImpl;

/**
 Created by sxuj4k on 3/17/2020.
 */
public class ApigeeGCMEncryption {//implements Execution {

	 public ExecutionResult execute(MessageContext messageContext,
	 ExecutionContext executionContext) {
	 
	 try {
	 
	 EncryptionUtil encryptionUtil = new EncryptionUtilImpl();
	 
	 //TODO Fetch/Generate public key to use for encryption // During encryption
	 //we would generate key, encrypt and send the msg back along with key in header
	 // which will be used to decrypt it 
	 String key = encryptionUtil.getEncryptionToken(EncryptionType.AES_GCM_3);
	 
	 Message message = messageContext.getMessage(); String body =
	 message.getContent(); String encryptedBody =
	 encryptionUtil.encrypt("AES_GCM", body, key);
	 message.setContent(encryptedBody); message.setHeader("encryptionKey", key);
	 messageContext.setRequestMessage(message);
	 
	 return ExecutionResult.SUCCESS;
	 
	 } catch (Exception e) { return ExecutionResult.ABORT; } }
	 

}
