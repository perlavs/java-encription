package com.fanniemae.apigee;

import com.apigee.flow.execution.ExecutionContext;
import com.apigee.flow.execution.ExecutionResult;
import com.apigee.flow.execution.spi.Execution;
import com.apigee.flow.message.Message;
import com.apigee.flow.message.MessageContext;
import com.fanniemae.apigee1.encryption.EncryptionUtil;
import com.fanniemae.apigee1.encryption.impl.EncryptionUtilImpl;

/**
 * Created by sxuj4k on 3/17/2020.
 */
public class ApigeeGCMDecryption implements Execution {
	
    public ExecutionResult execute(MessageContext messageContext, ExecutionContext executionContext) {

        try {

            EncryptionUtil encryptionUtil = new EncryptionUtilImpl();
            String key = messageContext.getMessage().getHeader("encryptionKey");
            //TODO Fetch/Generate public key to use for encryption

            Message message = messageContext.getMessage();
            String body = message.getContent();
            key = message.getHeader("encryptionKey");
            String decryptedBody = encryptionUtil.decrypt("AES_GCM", body, key);
            message.setContent(decryptedBody);
            messageContext.setRequestMessage(message);

            return ExecutionResult.SUCCESS;

        } catch (Exception e) {
            return ExecutionResult.ABORT;
        }
    }

}
